<?php

// database/factories/UmkmProfileFactory.php
namespace Database\Factories;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class UmkmProfileFactory extends Factory
{
    private static array $namesByCategory = [
        'Makanan' => ['Dapur Ibu Kartini', 'Warung Sate Mak Ijah', 'Nasi Uduk Bu Yuli', 'Ayam Geprek Berkah', 'Bakso Mang Ujang', 'Soto Betawi Haji Darman'],
        'Minuman' => ['Es Teh Segernya', 'Kedai Kopi Anten', 'Jus Sehat Ceria', 'Teh Poci Ratu', 'Susu Jahe Hangat', 'Kopi Kenangan Kampus'],
        'Kerajinan' => ['Kreasi Rotan Nusantara', 'Anyaman Bambu Lestari', 'Tenun Ikat Timur', 'Kriya Kayu Jati', 'Kreasi Lokal'],
        'Aksesoris' => ['Aksesoris Cantik Kita', 'Gelang Manik Sari', 'Perhiasan Etnik Nusa', 'Bros Cantik Handmade', 'Kalung Kayu Alam'],
        'Fashion' => ['Butik Hijab Aisyah', 'Kaos Distro Lokal', 'Baju Batik Modern', 'Fashion Muslimah Zahra', 'Sneakers Lokal Karya'],
    ];

    private static array $descriptions = [
        'Menyajikan produk berkualitas dengan harga terjangkau untuk semua kalangan.',
        'Usaha rumahan yang sudah berjalan lebih dari 3 tahun dengan pelanggan setia.',
        'Fokus pada produk lokal dengan sentuhan modern dan kemasan menarik.',
        'Selalu menjaga kualitas dan kesegaran bahan baku setiap hari.',
        'Cocok untuk acara sekolah, bazar, maupun festival komunitas.',
    ];

    public function definition(): array
    {
        $category = fake()->randomElement(array_keys(self::$namesByCategory));
        $locations = ['Jakarta Timur', 'Jakarta Selatan', 'Jakarta Barat', 'Jakarta Pusat', 'Jakarta Utara'];
        $audiences = ['Pelajar', 'Umum', 'Keluarga', 'Remaja'];

        $priceMin = fake()->randomElement([15000, 20000, 25000, 30000, 40000]);

        return [
            'user_id' => User::factory()->state(['role' => 'umkm']),

            'business_name' => fake()->randomElement(
                self::$namesByCategory[$category]
            ),

            'description' => fake()->randomElement(self::$descriptions),

            'category' => $category,

            'location' => fake()->randomElement($locations),

            'price_min' => $priceMin,

            'price_max' => $priceMin + fake()->randomElement([
                15000,
                25000,
                35000,
            ]),

            'target_audience' => fake()->randomElement($audiences),
        ];
    }
}
