<?php

// database/seeders/DatabaseSeeder.php
namespace Database\Seeders;

use App\Models\{Event, School, UmkmProfile, User};
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Akun school testing
        $schoolUser = User::factory()->create([
            'name' => 'Admin SMKN 26',
            'email' => 'school@venu.test',
            'role' => 'school',
        ]);
        $school = School::factory()->create([
            'user_id' => $schoolUser->id,
            'school_name' => 'SMKN 26 Jakarta',
        ]);

        // Akun umkm testing — "Kreasi Lokal", kategori Kerajinan, Jakarta Timur
        $umkmUser = User::factory()->create([
            'name' => 'Pemilik Kreasi Lokal',
            'email' => 'umkm@venu.test',
            'role' => 'umkm',
        ]);
        UmkmProfile::factory()->create([
            'user_id' => $umkmUser->id,
            'business_name' => 'Kreasi Lokal',
            'category' => 'Kerajinan',
            'location' => 'Jakarta Timur',
            'target_audience' => 'Keluarga',
            'price_min' => 20000,
            'price_max' => 40000,
        ]);

        // Event yang SENGAJA didesain match 100% dengan "Kreasi Lokal"
        Event::factory()->create([
            'school_id' => $school->id,
            'name' => 'Festival Budaya 2026',
            'slug' => 'festival-budaya-2026',
            'category' => 'Kerajinan',
            'location' => 'Jakarta Timur',
            'description' => 'Suasana event ini ramah untuk keluarga, cocok dikunjungi bersama orang tua dan anak.',
            'booth_price' => 30000, // masuk range 20rb-40rb punya Kreasi Lokal
            'status' => 'published',
        ]);

        // Event contoh dengan kategori beda (buat nunjukin skor rendah/menengah)
        Event::factory()->create([
            'school_id' => $school->id,
            'name' => 'Pekan Kuliner Sekolah 2026',
            'category' => 'Makanan',
            'status' => 'published',
        ]);

        // Data variatif tambahan
        School::factory(4)->create();
        UmkmProfile::factory(20)->create();
        Event::factory(12)->create();

        // Contoh event draft (harus tidak muncul di discovery/match)
        Event::factory()->create([
            'school_id' => $school->id,
            'name' => 'Event Draft Contoh',
            'status' => 'draft',
        ]);
    }
}
