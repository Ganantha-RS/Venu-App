<?php

namespace App\Http\Requests\Umkm;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;

class StoreApplicationRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    // app/Http/Requests/Umkm/StoreApplicationRequest.php
    public function rules(): array
    {
        return [
            'event_id' => 'required|exists:events,id',
        ];
    }
}
