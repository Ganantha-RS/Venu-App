import Navbar from "../../components/layout/Navbar";
import SchoolNavbar from "../../components/layout/SchoolNavbar";
import { useAuth } from "../../context/useAuth";

export default function SchoolHome() {
    const { user } = useAuth();

    return (
        <div className="min-h-screen bg-surface">
            <SchoolNavbar />
            <div className="mx-auto max-w-7xl px-4 py-12 md:px-8">
                <h1 className="text-3xl font-extrabold text-navy">
                    Selamat datang, {user?.name}
                </h1>

                <p className="mt-2 text-navy/60">
                    Ini adalah beranda untuk akun Sekolah.
                </p>
            </div>
        </div>
    );
}