import { useState } from "react";
import {
  FiArrowUpRight,
  FiCalendar,
  FiMapPin,
  FiUsers,
  FiMoreHorizontal,
  FiPlus,
  FiTrash2,
  FiSend,
  FiClock,
} from "react-icons/fi";
import { LuSparkles } from "react-icons/lu";

import SchoolNavbar from "../../components/layout/SchoolNavbar";
import Button from "../../components/common/Button";
import EventFormModal from "../../components/event-management/EventFormModal";
import { useMyEvents } from "../../features/event-management/useMyEvents";
import {
  createEvent,
  deleteEvent,
  publishEvent,
} from "../../features/event-management/eventManagementApi";

const STATUS_STYLE = {
  draft: {
    label: "Draft",
    className: "bg-slate-100 text-slate-600",
  },
  published: {
    label: "Aktif",
    className: "bg-emerald-50 text-emerald-700",
  },
  closed: {
    label: "Ditutup",
    className: "bg-orange-50 text-orange-700",
  },
  completed: {
    label: "Selesai",
    className: "bg-blue-50 text-blue-700",
  },
};

export default function ManageEvents() {
  const { events, isLoading, error, reload } = useMyEvents();

  const [showForm, setShowForm] = useState(false);
  const [actioningId, setActioningId] = useState(null);

  const handleCreate = async (payload) => {
    try {
      await createEvent(payload);
      setShowForm(false);
      reload();
    } catch (err) {
      alert(
        err.response?.data?.message ||
          "Gagal membuat event."
      );
    }
  };

  const handlePublish = async (eventId) => {
    setActioningId(eventId);

    try {
      await publishEvent(eventId);
      reload();
    } catch (err) {
      alert(
        err.response?.data?.message ||
          "Gagal mempublikasikan event."
      );
    } finally {
      setActioningId(null);
    }
  };

  const handleDelete = async (eventId) => {
    if (
      !confirm(
        "Hapus event ini? Hanya event berstatus draft yang dapat dihapus."
      )
    ) {
      return;
    }

    setActioningId(eventId);

    try {
      await deleteEvent(eventId);
      reload();
    } catch (err) {
      alert(
        err.response?.data?.message ||
          "Gagal menghapus event."
      );
    } finally {
      setActioningId(null);
    }
  };

  const publishedCount = events.filter(
    (event) => event.status === "published"
  ).length;

  const draftCount = events.filter(
    (event) => event.status === "draft"
  ).length;

  const totalCapacity = events.reduce(
    (total, event) =>
      total + Number(event.booth_capacity || 0),
    0
  );

  return (
    <div className="min-h-screen bg-[#FAFAF9] text-[#111827]">
      <SchoolNavbar />

      <main className="relative overflow-hidden">

        <div className="pointer-events-none absolute right-10 top-10 hidden opacity-40 lg:block">
          <div className="grid grid-cols-8 gap-3">
            {Array.from({ length: 48 }).map((_, index) => (
              <span
                key={index}
                className="h-1 w-1 rounded-full bg-[#9CA3AF]"
              />
            ))}
          </div>
        </div>

        <div className="relative mx-auto max-w-[1280px] px-5 py-10 md:px-8 lg:py-14">
          {/* ================= HERO ================= */}

          <section className="relative mb-12">
            <div className="max-w-3xl">
              <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-[#E5E7EB] bg-white px-3 py-1.5 shadow-sm">
                <LuSparkles
                  size={14}
                  className="text-[#F97316]"
                />

                <span className="text-[11px] font-semibold tracking-wide text-[#4B5563]">
                  RUANG KELOLA EVENT
                </span>
              </div>

              <h1 className="text-5xl font-bold leading-[0.95] tracking-[-2.8px] text-[#111827] md:text-6xl lg:text-7xl">
                Event kamu,
                <br />
                <span className="text-[#F97316]">
                  peluang mereka.
                </span>
              </h1>

              <p className="mt-6 max-w-2xl text-sm leading-6 text-[#6B7280] md:text-base">
                Kelola seluruh event sekolahmu dalam satu
                ruang. Publikasikan event, temukan tenant,
                dan buka lebih banyak peluang untuk UMKM.
              </p>
            </div>

            {/* CREATE BUTTON */}

            <div className="mt-7 md:absolute md:right-0 md:bottom-0 md:mt-0">
              <button
                type="button"
                onClick={() => setShowForm(true)}
                className="group inline-flex items-center gap-3 rounded-full bg-[#111827] px-6 py-3.5 text-sm font-semibold text-white shadow-lg shadow-black/10 transition-all duration-300 hover:-translate-y-1 hover:bg-[#F97316]"
              >
                <FiPlus
                  size={17}
                  className="transition-transform duration-300 group-hover:rotate-90"
                />

                Buat Event

                <FiArrowUpRight
                  size={17}
                  className="transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                />
              </button>
            </div>
          </section>

          {/* ================= STATS ================= */}

          <section className="mb-12 grid grid-cols-2 border-y border-[#E7E5E4] md:grid-cols-4">
            <StatItem
              number={events.length}
              label="Total Event"
            />

            <StatItem
              number={publishedCount}
              label="Event Aktif"
              accent
            />

            <StatItem
              number={draftCount}
              label="Masih Draft"
            />

            <StatItem
              number={totalCapacity}
              label="Kapasitas Booth"
            />
          </section>

          {/* ================= SECTION TITLE ================= */}

          <section className="mb-7 flex items-end justify-between">
            <div>
              <p className="mb-2 text-[10px] font-bold uppercase tracking-[0.2em] text-[#F97316]">
                Koleksi Event
              </p>

              <h2 className="text-2xl font-bold tracking-[-0.8px] text-[#111827] md:text-3xl">
                Event Saya
              </h2>
            </div>

            {events.length > 0 && (
              <span className="hidden text-xs text-[#9CA3AF] sm:block">
                {events.length} event terdaftar
              </span>
            )}
          </section>

          {/* ================= LOADING ================= */}

          {isLoading && (
            <div className="border-y border-[#E7E5E4] py-20 text-center">
              <div className="mx-auto mb-4 h-7 w-7 animate-spin rounded-full border-2 border-[#E5E7EB] border-t-[#F97316]" />

              <p className="text-sm text-[#9CA3AF]">
                Memuat event...
              </p>
            </div>
          )}

          {/* ================= ERROR ================= */}

          {!isLoading && error && (
            <div className="border border-red-100 bg-red-50 px-6 py-5 text-sm text-red-600">
              {error}
            </div>
          )}

          {/* ================= EMPTY ================= */}

          {!isLoading &&
            !error &&
            events.length === 0 && (
              <EmptyState
                onCreate={() => setShowForm(true)}
              />
            )}

          {/* ================= EVENTS ================= */}

          {!isLoading &&
            !error &&
            events.length > 0 && (
              <section className="space-y-5">
                {events.map((event, index) => {
                  const status =
                    STATUS_STYLE[event.status] ||
                    STATUS_STYLE.draft;

                  const isActioning =
                    actioningId === event.id;

                  return (
                    <article
                      key={event.id}
                      className="group relative overflow-hidden border border-[#E7E5E4] bg-white transition-all duration-500 hover:-translate-y-1 hover:border-[#D6D3D1] hover:shadow-[0_20px_50px_rgba(17,24,39,0.08)]"
                    >
                      {/* NUMBER */}

                      <div className="absolute left-5 top-5 hidden text-[11px] font-bold tracking-widest text-[#D6D3D1] md:block">
                        {String(index + 1).padStart(2, "0")}
                      </div>

                      <div className="grid md:grid-cols-[90px_1fr_auto]">
                        {/* EVENT INDEX */}

                        <div className="hidden items-center justify-center border-r border-[#E7E5E4] md:flex">
                          <span className="rotate-[-90deg] text-[10px] font-semibold uppercase tracking-[0.25em] text-[#A8A29E]">
                            EVENT
                          </span>
                        </div>

                        {/* CONTENT */}

                        <div className="min-w-0 p-6 md:p-8">
                          <div className="mb-4 flex flex-wrap items-center gap-3">
                            <span
                              className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[10px] font-bold uppercase tracking-wide ${status.className}`}
                            >
                              <span className="h-1.5 w-1.5 rounded-full bg-current" />

                              {status.label}
                            </span>

                            {event.category && (
                              <span className="text-[11px] font-medium text-[#A8A29E]">
                                {event.category}
                              </span>
                            )}
                          </div>

                          <div className="flex items-start justify-between gap-4">
                            <div>
                              <h3 className="max-w-2xl text-2xl font-extrabold leading-tight tracking-[-1px] text-[#111827] transition-colors duration-300 group-hover:text-[#F97316] md:text-3xl">
                                {event.name}
                              </h3>

                              <div className="mt-4 flex flex-wrap gap-x-5 gap-y-2">
                                <InfoItem
                                  icon={FiCalendar}
                                  text={formatDate(
                                    event.event_date
                                  )}
                                />

                                <InfoItem
                                  icon={FiMapPin}
                                  text={event.location}
                                />

                                <InfoItem
                                  icon={FiUsers}
                                  text={`${event.booth_capacity} booth`}
                                />
                              </div>
                            </div>
                          </div>

                          {/* PRICE */}

                          <div className="mt-7 flex flex-wrap items-center gap-6 border-t border-[#F1F0EF] pt-5">
                            <div>
                              <p className="mb-1 text-[9px] font-bold uppercase tracking-[0.18em] text-[#A8A29E]">
                                Harga Booth
                              </p>

                              <p className="text-sm font-bold text-[#111827]">
                                Rp
                                {Number(
                                  event.booth_price || 0
                                ).toLocaleString("id-ID")}
                              </p>
                            </div>

                            <div className="h-8 w-px bg-[#E7E5E4]" />

                            <div>
                              <p className="mb-1 text-[9px] font-bold uppercase tracking-[0.18em] text-[#A8A29E]">
                                Kapasitas
                              </p>

                              <p className="text-sm font-bold text-[#111827]">
                                {event.booth_capacity || 0}{" "}
                                booth
                              </p>
                            </div>
                          </div>
                        </div>

                        {/* ACTIONS */}

                        <div className="flex items-center border-t border-[#E7E5E4] bg-[#FAFAF9] p-5 md:w-[190px] md:border-l md:border-t-0 md:p-6">
                          {event.status === "draft" ? (
                            <div className="flex w-full flex-col gap-2">
                              <button
                                type="button"
                                disabled={isActioning}
                                onClick={() =>
                                  handlePublish(
                                    event.id
                                  )
                                }
                                className="group/button flex w-full items-center justify-between rounded-xl bg-[#111827] px-4 py-3 text-xs font-semibold text-white transition-all hover:bg-[#F97316] disabled:cursor-not-allowed disabled:opacity-50"
                              >
                                {isActioning
                                  ? "Memproses..."
                                  : "Publikasikan"}

                                <FiSend
                                  size={15}
                                  className="transition-transform group-hover/button:-translate-y-0.5 group-hover/button:translate-x-0.5"
                                />
                              </button>

                              <button
                                type="button"
                                disabled={isActioning}
                                onClick={() =>
                                  handleDelete(
                                    event.id
                                  )
                                }
                                className="flex w-full items-center justify-center gap-2 rounded-xl px-4 py-3 text-xs font-medium text-[#A8A29E] transition hover:bg-red-50 hover:text-red-600 disabled:opacity-50"
                              >
                                <FiTrash2 size={14} />
                                Hapus Draft
                              </button>
                            </div>
                          ) : (
                            <div className="flex w-full flex-col gap-3">
                              <button
                                type="button"
                                className="flex w-full items-center justify-between rounded-xl border border-[#E7E5E4] bg-white px-4 py-3 text-xs font-semibold text-[#111827] transition hover:border-[#111827]"
                              >
                                Kelola Event

                                <FiArrowUpRight
                                  size={15}
                                />
                              </button>

                              <button
                                type="button"
                                className="flex items-center justify-center gap-2 py-2 text-[11px] font-medium text-[#A8A29E] transition hover:text-[#111827]"
                              >
                                <FiMoreHorizontal
                                  size={15}
                                />

                                Opsi lainnya
                              </button>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* HOVER ACCENT */}

                      <div className="absolute bottom-0 left-0 h-[3px] w-0 bg-[#F97316] transition-all duration-500 group-hover:w-full" />
                    </article>
                  );
                })}
              </section>
            )}

          {/* ================= BOTTOM MESSAGE ================= */}

          {events.length > 0 && !isLoading && (
            <section className="mt-16 flex flex-col items-start justify-between gap-5 border-t border-[#E7E5E4] pt-8 md:flex-row md:items-center">
              <div>
                <p className="text-sm font-semibold text-[#111827]">
                  Siap membuka peluang baru?
                </p>

                <p className="mt-1 text-xs text-[#A8A29E]">
                  Buat event berikutnya dan temukan UMKM
                  yang tepat.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setShowForm(true)}
                className="inline-flex items-center gap-2 text-xs font-bold text-[#F97316] transition hover:gap-3"
              >
                Buat event baru
                <FiArrowUpRight size={15} />
              </button>
            </section>
          )}
        </div>
      </main>

      {/* ================= MODAL ================= */}

      {showForm && (
        <EventFormModal
          onClose={() => setShowForm(false)}
          onSubmit={handleCreate}
        />
      )}
    </div>
  );
}

/* =========================================================
   STAT ITEM
========================================================= */

function StatItem({
  number,
  label,
  accent = false,
}) {
  return (
    <div className="border-r border-[#E7E5E4] px-5 py-6 first:pl-0 last:border-r-0 md:px-7 md:py-8">
      <p
        className={`text-3xl font-extrabold tracking-[-1.5px] md:text-4xl ${
          accent ? "text-[#F97316]" : "text-[#111827]"
        }`}
      >
        {number}
      </p>

      <p className="mt-1 text-[10px] font-semibold uppercase tracking-[0.15em] text-[#A8A29E]">
        {label}
      </p>
    </div>
  );
}

/* =========================================================
   INFO ITEM
========================================================= */

function InfoItem({
  icon: Icon,
  text,
}) {
  return (
    <div className="flex items-center gap-1.5 text-[11px] text-[#78716C]">
      <Icon
        size={13}
        className="text-[#A8A29E]"
      />

      <span>{text || "-"}</span>
    </div>
  );
}

/* =========================================================
   EMPTY STATE
========================================================= */

function EmptyState({
  onCreate,
}) {
  return (
    <div className="relative overflow-hidden border border-[#E7E5E4] bg-white px-6 py-20 text-center md:py-28">

      <div className="relative">
        <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-[#111827] text-white">
          <FiCalendar size={25} />
        </div>

        <p className="mb-2 text-[10px] font-bold uppercase tracking-[0.2em] text-[#F97316]">
          Belum ada event
        </p>

        <h3 className="text-2xl font-bold tracking-[-0.8px] text-[#111827]">
          Saatnya membuat peluang pertama.
        </h3>

        <p className="mx-auto mt-3 max-w-md text-sm leading-6 text-[#A8A29E]">
          Buat event sekolahmu dan mulai temukan UMKM
          yang sesuai dengan kebutuhan acara.
        </p>

        <button
          type="button"
          onClick={onCreate}
          className="mt-7 inline-flex items-center gap-2 rounded-full bg-[#F97316] px-6 py-3 text-xs font-bold text-white transition hover:bg-[#EA580C]"
        >
          <FiPlus size={15} />
          Buat Event Pertama
        </button>
      </div>
    </div>
  );
}

/* =========================================================
   FORMAT DATE
========================================================= */

function formatDate(date) {
  if (!date) {
    return "-";
  }

  const parsedDate = new Date(date);

  if (Number.isNaN(parsedDate.getTime())) {
    return date;
  }

  return parsedDate.toLocaleDateString("id-ID", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}